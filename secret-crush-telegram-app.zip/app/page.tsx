"use client"

import { AppShell } from "@/components/app-shell"

export default function Page() {
  return <AppShell />
}
