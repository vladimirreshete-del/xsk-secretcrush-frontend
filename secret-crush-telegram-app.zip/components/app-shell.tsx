"use client"

import { useEffect } from "react"
import { initTelegramApp } from "@/lib/telegram"
import { useAppStore } from "@/lib/store"
import { BottomNav } from "@/components/bottom-nav"
import { OnboardingScreen } from "@/components/screens/onboarding-screen"
import { LocationScreen } from "@/components/screens/location-screen"
import { ProfileScreen } from "@/components/screens/profile-screen"
import { FeedScreen } from "@/components/screens/feed-screen"
import { MatchesScreen } from "@/components/screens/matches-screen"
import { ChatScreen } from "@/components/screens/chat-screen"
import { LikesScreen } from "@/components/screens/likes-screen"
import { ProScreen } from "@/components/screens/pro-screen"
import { ProfileViewScreen } from "@/components/screens/profile-view-screen"

const SCREENS_WITH_NAV = ["feed", "matches", "profile-view", "likes"]

export function AppShell() {
  const screen = useAppStore((s) => s.screen)

  useEffect(() => {
    initTelegramApp()
  }, [])

  const showNav = SCREENS_WITH_NAV.includes(screen)

  const renderScreen = () => {
    if (screen.startsWith("chat-")) {
      const matchId = screen.replace("chat-", "")
      return <ChatScreen matchId={matchId} />
    }

    switch (screen) {
      case "onboarding":
        return <OnboardingScreen />
      case "location":
        return <LocationScreen />
      case "profile":
        return <ProfileScreen />
      case "feed":
        return <FeedScreen />
      case "matches":
        return <MatchesScreen />
      case "likes":
        return <LikesScreen />
      case "pro":
        return <ProScreen />
      case "profile-view":
        return <ProfileViewScreen />
      default:
        return <OnboardingScreen />
    }
  }

  // Chat screen is fullscreen
  if (screen.startsWith("chat-")) {
    return renderScreen()
  }

  // Pro screen is fullscreen
  if (screen === "pro") {
    return renderScreen()
  }

  return (
    <div className="flex h-[100dvh] flex-col">
      <div className="flex-1 overflow-y-auto">{renderScreen()}</div>
      {showNav && <BottomNav />}
    </div>
  )
}
