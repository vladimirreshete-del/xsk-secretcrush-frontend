"use client"

import { MapPin } from "lucide-react"
import type { UserProfile } from "@/lib/types"

interface ProfileCardProps {
  profile: UserProfile
  blurred?: boolean
}

export function ProfileCard({ profile, blurred = true }: ProfileCardProps) {
  return (
    <div className="glass glow-primary relative w-full overflow-hidden rounded-2xl">
      {/* Photo area */}
      <div className="relative aspect-[3/4] w-full">
        <div
          className={`flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/15 via-card/80 to-primary/5 ${
            blurred ? "backdrop-blur-md" : ""
          }`}
        >
          <div className="flex h-24 w-24 items-center justify-center rounded-full bg-primary/15 text-4xl font-bold text-primary">
            {profile.name.charAt(0)}
          </div>
        </div>
        {blurred && (
          <div className="absolute inset-0 bg-background/20 backdrop-blur-xl" />
        )}

        {/* Bottom overlay */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background/90 via-background/50 to-transparent px-4 pb-4 pt-16">
          <h3 className="text-xl font-bold text-foreground">
            {profile.name}, {profile.age}
          </h3>
          <div className="mt-1 flex items-center gap-1 text-foreground/60">
            <MapPin className="h-3.5 w-3.5" />
            <span className="text-sm">{profile.district}</span>
          </div>
        </div>
      </div>

      {/* Bio */}
      <div className="px-4 py-3">
        <p className="text-sm leading-relaxed text-muted-foreground">
          {profile.bio}
        </p>
      </div>
    </div>
  )
}
