"use client"

import { Flame, MessageCircle, User } from "lucide-react"
import { useAppStore } from "@/lib/store"

const TABS = [
  { id: "feed", label: "Лента", icon: Flame },
  { id: "matches", label: "Пары", icon: MessageCircle },
  { id: "profile-view", label: "Профиль", icon: User },
] as const

export function BottomNav() {
  const screen = useAppStore((s) => s.screen)
  const setScreen = useAppStore((s) => s.setScreen)

  const activeTab = TABS.find((t) => screen.startsWith(t.id))?.id || "feed"

  return (
    <nav
      className="glass-strong flex items-center justify-around px-2 pb-[env(safe-area-inset-bottom,8px)] pt-2"
      role="tablist"
      aria-label="Главная навигация"
    >
      {TABS.map((tab) => {
        const isActive = activeTab === tab.id
        return (
          <button
            key={tab.id}
            role="tab"
            aria-selected={isActive}
            className={`flex flex-1 flex-col items-center gap-0.5 rounded-lg py-1.5 transition-colors ${
              isActive
                ? "text-primary"
                : "text-muted-foreground hover:text-foreground"
            }`}
            onClick={() => setScreen(tab.id === "profile-view" ? "profile-view" : tab.id)}
          >
            <tab.icon
              className={`h-5 w-5 ${isActive ? "drop-shadow-[0_0_6px_hsla(340,82%,55%,0.4)]" : ""}`}
              strokeWidth={isActive ? 2.5 : 2}
            />
            <span className="text-[10px] font-medium">{tab.label}</span>
          </button>
        )
      })}
    </nav>
  )
}
