"use client"

import { useState, useMemo } from "react"
import { MapPin, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { useAppStore } from "@/lib/store"
import { CITIES, DISTRICTS } from "@/lib/mock-data"

export function LocationScreen() {
  const { city, district, setCity, setDistrict, setScreen } = useAppStore()
  const [search, setSearch] = useState("")

  const filteredCities = useMemo(() => {
    if (!search) return CITIES
    return CITIES.filter((c) =>
      c.toLowerCase().includes(search.toLowerCase())
    )
  }, [search])

  const districts = city ? DISTRICTS[city] || [] : []

  return (
    <div className="relative flex min-h-[100dvh] flex-col px-6 pb-8 pt-12">
      {/* Background glow */}
      <div className="pointer-events-none absolute right-0 top-0 h-48 w-48 rounded-full bg-primary/10 blur-[80px]" />

      <div className="relative mb-8">
        <div className="mb-1 flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/20">
            <MapPin className="h-4 w-4 text-primary" />
          </div>
          <h1 className="text-xl font-bold text-foreground">{"Твоё местоположение"}</h1>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          {"Поможем найти людей рядом с тобой"}
        </p>
      </div>

      <div className="relative flex flex-1 flex-col gap-5">
        <div className="flex flex-col gap-2">
          <Label className="text-sm font-medium text-foreground">{"Город"}</Label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Поиск города..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="rounded-xl border-border/50 bg-card/60 pl-10 backdrop-blur-sm"
            />
          </div>
          <div className="glass flex max-h-48 flex-col gap-1 overflow-y-auto rounded-xl p-2">
            {filteredCities.map((c) => (
              <button
                key={c}
                onClick={() => {
                  setCity(c)
                  setDistrict("")
                  setSearch(c)
                }}
                className={`rounded-lg px-3 py-2.5 text-left text-sm transition-all ${
                  city === c
                    ? "bg-primary/15 font-medium text-primary"
                    : "text-foreground/80 hover:bg-muted/50"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {city && districts.length > 0 && (
          <div className="flex flex-col gap-2">
            <Label className="text-sm font-medium text-foreground">{"Район"}</Label>
            <Select value={district} onValueChange={setDistrict}>
              <SelectTrigger className="rounded-xl border-border/50 bg-card/60 backdrop-blur-sm">
                <SelectValue placeholder="Выберите район" />
              </SelectTrigger>
              <SelectContent className="glass-strong rounded-xl">
                {districts.map((d) => (
                  <SelectItem key={d} value={d}>
                    {d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
      </div>

      <Button
        size="lg"
        className="glow-primary mt-6 w-full rounded-full text-base font-semibold"
        disabled={!city || !district}
        onClick={() => setScreen("profile")}
      >
        {"Продолжить"}
      </Button>
    </div>
  )
}
