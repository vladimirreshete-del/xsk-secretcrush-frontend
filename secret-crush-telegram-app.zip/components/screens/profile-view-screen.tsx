"use client"

import { MapPin, Camera, Heart, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useAppStore } from "@/lib/store"

export function ProfileViewScreen() {
  const { profile, city, district, setScreen } = useAppStore()

  return (
    <div className="flex flex-col px-4 pb-4 pt-3">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-lg font-bold text-foreground">{"Профиль"}</h1>
        <Button
          variant="ghost"
          size="sm"
          className="h-8 w-8 p-0 text-muted-foreground"
          onClick={() => setScreen("profile")}
        >
          <Settings className="h-5 w-5" />
          <span className="sr-only">{"Редактировать профиль"}</span>
        </Button>
      </div>

      {/* Profile card */}
      <div className="glass glow-primary flex flex-col items-center gap-4 rounded-2xl p-6">
        {/* Avatar */}
        <div className="relative">
          <div className="flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-primary/25 to-primary/5">
            {profile.photos && profile.photos.length > 0 ? (
              <img
                src={profile.photos[0]}
                alt="Профиль"
                className="h-full w-full rounded-full object-cover"
              />
            ) : (
              <span className="text-3xl font-bold text-primary">
                {(profile.name || "?").charAt(0)}
              </span>
            )}
          </div>
          <button
            onClick={() => setScreen("profile")}
            className="glow-primary absolute -bottom-1 -right-1 flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground"
          >
            <Camera className="h-4 w-4" />
          </button>
        </div>

        <div className="text-center">
          <h2 className="text-xl font-bold text-foreground">
            {profile.name || "Твоё имя"}{profile.age ? `, ${profile.age}` : ""}
          </h2>
          {city && (
            <div className="mt-1 flex items-center justify-center gap-1 text-muted-foreground">
              <MapPin className="h-3.5 w-3.5" />
              <span className="text-sm">{district}, {city}</span>
            </div>
          )}
        </div>

        {profile.bio && (
          <p className="text-center text-sm leading-relaxed text-muted-foreground">
            {profile.bio}
          </p>
        )}

        {/* Photo thumbnails */}
        {profile.photos && profile.photos.length > 0 && (
          <div className="flex gap-2">
            {profile.photos.map((photo, i) => (
              <div
                key={i}
                className="h-16 w-16 overflow-hidden rounded-lg"
              >
                <img
                  src={photo}
                  alt={`Фото ${i + 1}`}
                  className="h-full w-full object-cover"
                />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick actions */}
      <div className="mt-4 flex flex-col gap-2">
        <button
          onClick={() => setScreen("likes")}
          className="glass flex items-center gap-3 rounded-xl p-4 transition-all active:scale-[0.98]"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/15">
            <Heart className="h-5 w-5 text-primary" />
          </div>
          <div className="flex flex-1 flex-col items-start">
            <span className="text-sm font-semibold text-foreground">
              {"Кому ты нравишься"}
            </span>
            <span className="text-xs text-muted-foreground">
              {"Узнай своих тайных поклонников"}
            </span>
          </div>
          <Badge variant="secondary" className="rounded-full bg-primary/15 text-primary">3</Badge>
        </button>

        <button
          onClick={() => setScreen("pro")}
          className="glass flex items-center gap-3 rounded-xl p-4 transition-all active:scale-[0.98]"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/15">
            <span className="text-sm font-bold text-amber-400">PRO</span>
          </div>
          <div className="flex flex-1 flex-col items-start">
            <span className="text-sm font-semibold text-foreground">
              {"Перейти на PRO"}
            </span>
            <span className="text-xs text-muted-foreground">
              {"Разблокируй все функции"}
            </span>
          </div>
        </button>
      </div>
    </div>
  )
}
