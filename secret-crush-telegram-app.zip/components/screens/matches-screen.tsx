"use client"

import { MessageCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { CountdownTimer } from "@/components/countdown-timer"
import { useAppStore } from "@/lib/store"
import { MOCK_MATCHES } from "@/lib/mock-data"

export function MatchesScreen() {
  const setScreen = useAppStore((s) => s.setScreen)

  return (
    <div className="flex flex-col px-4 pb-4 pt-3">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-lg font-bold text-foreground">{"Совпадения"}</h1>
        <Badge variant="secondary" className="rounded-full bg-primary/15 text-xs text-primary">
          {MOCK_MATCHES.length}
        </Badge>
      </div>

      {MOCK_MATCHES.length === 0 ? (
        <div className="flex flex-1 flex-col items-center justify-center py-20 text-center">
          <div className="glass mb-3 flex h-16 w-16 items-center justify-center rounded-full">
            <MessageCircle className="h-8 w-8 text-muted-foreground" />
          </div>
          <p className="text-sm text-muted-foreground">
            {"Пока нет совпадений. Продолжай листать!"}
          </p>
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {MOCK_MATCHES.map((match) => (
            <button
              key={match.id}
              onClick={() => setScreen(`chat-${match.id}`)}
              className="glass flex items-center gap-3 rounded-xl p-3 transition-all active:scale-[0.98]"
            >
              {/* Avatar */}
              <div className="relative flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-primary/25 to-primary/5">
                <span className="text-lg font-bold text-primary">
                  {match.user.name.charAt(0)}
                </span>
              </div>

              {/* Info */}
              <div className="flex flex-1 flex-col items-start gap-0.5 text-left">
                <div className="flex w-full items-center justify-between">
                  <span className="text-sm font-semibold text-foreground">
                    {match.user.name}, {match.user.age}
                  </span>
                  <CountdownTimer targetDate={match.photosUnlockAt} compact />
                </div>
                <p className="line-clamp-1 text-xs text-muted-foreground">
                  {match.lastMessage || "Скажи привет!"}
                </p>
              </div>

              {/* Unread badge */}
              {match.unreadCount > 0 && (
                <div className="glow-primary flex h-5 min-w-[20px] items-center justify-center rounded-full bg-primary px-1.5">
                  <span className="text-[10px] font-bold text-primary-foreground">
                    {match.unreadCount}
                  </span>
                </div>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
