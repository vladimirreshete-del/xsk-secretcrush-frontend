"use client"

import { Heart, Lock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useAppStore } from "@/lib/store"
import { MOCK_PROFILES } from "@/lib/mock-data"

export function LikesScreen() {
  const setScreen = useAppStore((s) => s.setScreen)

  const likedProfiles = MOCK_PROFILES.slice(0, 3)

  return (
    <div className="flex flex-col px-4 pb-4 pt-3">
      <div className="mb-4">
        <h1 className="text-lg font-bold text-foreground">{"Кому ты нравишься"}</h1>
        <p className="text-sm text-muted-foreground">
          {"Кто-то заинтересовался тобой"}
        </p>
      </div>

      {/* Blurred profiles grid */}
      <div className="mb-6 grid grid-cols-3 gap-3">
        {likedProfiles.map((profile) => (
          <div
            key={profile.id}
            className="glass relative overflow-hidden rounded-xl"
          >
            <div className="aspect-[3/4] bg-gradient-to-br from-primary/15 to-primary/5">
              <div className="flex h-full items-center justify-center">
                <span className="text-2xl font-bold text-primary/30">
                  {profile.name.charAt(0)}
                </span>
              </div>
            </div>
            {/* Blur overlay */}
            <div className="absolute inset-0 bg-background/30 backdrop-blur-lg" />
            <div className="absolute inset-0 flex items-center justify-center">
              <Lock className="h-6 w-6 text-muted-foreground/50" />
            </div>
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background/60 to-transparent px-2 pb-2 pt-6">
              <p className="text-xs font-medium text-foreground blur-sm">
                {profile.name}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* CTA */}
      <div className="glass glow-primary flex flex-col items-center gap-3 rounded-2xl p-6 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-primary/15">
          <Heart className="h-7 w-7 text-primary" fill="currentColor" />
        </div>
        <h2 className="text-base font-bold text-foreground">
          {"Ты кому-то нравишься!"}
        </h2>
        <p className="text-sm text-muted-foreground">
          {"Оформи PRO, чтобы узнать кому и совпасть мгновенно."}
        </p>
        <Button
          size="lg"
          className="glow-primary mt-2 w-full rounded-full text-base font-semibold"
          onClick={() => setScreen("pro")}
        >
          {"Перейти на PRO"}
        </Button>
      </div>
    </div>
  )
}
