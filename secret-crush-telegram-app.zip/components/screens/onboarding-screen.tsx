"use client"

import { Heart, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useAppStore } from "@/lib/store"

export function OnboardingScreen() {
  const setScreen = useAppStore((s) => s.setScreen)
  const setOnboarded = useAppStore((s) => s.setOnboarded)

  return (
    <div className="relative flex min-h-[100dvh] flex-col items-center justify-center overflow-hidden px-6">
      {/* Background glow effects */}
      <div className="pointer-events-none absolute -top-32 left-1/2 h-64 w-64 -translate-x-1/2 rounded-full bg-primary/20 blur-[100px]" />
      <div className="pointer-events-none absolute bottom-20 right-0 h-48 w-48 rounded-full bg-primary/10 blur-[80px]" />

      <div className="relative flex flex-col items-center gap-8 text-center">
        {/* Logo */}
        <div className="glass glow-primary-strong flex h-24 w-24 items-center justify-center rounded-3xl">
          <Heart className="h-12 w-12 text-primary" fill="currentColor" />
        </div>

        <div className="flex flex-col gap-3">
          <h1 className="text-balance text-3xl font-bold tracking-tight text-foreground">
            XSK SecretCrush
          </h1>
          <p className="text-balance text-base leading-relaxed text-muted-foreground">
            {"Анонимные взаимные симпатии в твоём городе"}
          </p>
        </div>

        {/* Feature pills */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          {["Анонимно", "Безопасно", "Рядом с тобой"].map((tag) => (
            <div
              key={tag}
              className="glass flex items-center gap-1.5 rounded-full px-3.5 py-1.5"
            >
              <Sparkles className="h-3 w-3 text-primary" />
              <span className="text-xs font-medium text-foreground/80">{tag}</span>
            </div>
          ))}
        </div>

        <div className="mt-4 flex w-full max-w-xs flex-col gap-3">
          <Button
            size="lg"
            className="glow-primary w-full rounded-full text-base font-semibold"
            onClick={() => {
              setOnboarded(true)
              setScreen("location")
            }}
          >
            {"Начать"}
          </Button>
          <p className="text-xs text-muted-foreground">
            {"Продолжая, вы принимаете Условия использования"}
          </p>
        </div>
      </div>
    </div>
  )
}
