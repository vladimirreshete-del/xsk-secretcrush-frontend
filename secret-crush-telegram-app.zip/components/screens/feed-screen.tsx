"use client"

import { useState } from "react"
import { X, Heart, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ProfileCard } from "@/components/profile-card"
import { useAppStore } from "@/lib/store"
import { MOCK_PROFILES, DAILY_LIKES_LIMIT } from "@/lib/mock-data"

export function FeedScreen() {
  const { currentProfileIndex, nextProfile, dailyLikesUsed, incrementLikes } =
    useAppStore()
  const [animating, setAnimating] = useState<"left" | "right" | "up" | null>(null)

  const remainingLikes = DAILY_LIKES_LIMIT - dailyLikesUsed
  const currentProfile = MOCK_PROFILES[currentProfileIndex % MOCK_PROFILES.length]

  const handleAction = (action: "pass" | "like" | "super") => {
    if (action !== "pass" && remainingLikes <= 0) return

    const dir = action === "pass" ? "left" : action === "super" ? "up" : "right"
    setAnimating(dir)

    setTimeout(() => {
      if (action !== "pass") {
        incrementLikes()
      }
      nextProfile()
      setAnimating(null)
    }, 300)
  }

  return (
    <div className="flex flex-col px-4 pb-4 pt-3">
      {/* Header */}
      <div className="mb-3 flex items-center justify-between">
        <h1 className="text-lg font-bold text-foreground">{"Знакомства"}</h1>
        <div className="glass flex items-center gap-1.5 rounded-full px-3 py-1.5">
          <Heart className="h-3.5 w-3.5 text-primary" />
          <span className="text-xs font-semibold text-primary">
            {remainingLikes} {"осталось"}
          </span>
        </div>
      </div>

      {/* Card */}
      <div className="relative">
        <div
          className={`transition-all duration-300 ease-out ${
            animating === "left"
              ? "-translate-x-full rotate-[-12deg] opacity-0"
              : animating === "right"
              ? "translate-x-full rotate-[12deg] opacity-0"
              : animating === "up"
              ? "-translate-y-1/2 scale-95 opacity-0"
              : ""
          }`}
        >
          <ProfileCard profile={currentProfile} blurred />
        </div>
      </div>

      {/* Action buttons */}
      <div className="mt-4 flex items-center justify-center gap-4">
        <Button
          variant="outline"
          size="lg"
          className="glass h-14 w-14 rounded-full border-0 p-0"
          onClick={() => handleAction("pass")}
        >
          <X className="h-6 w-6 text-muted-foreground" />
          <span className="sr-only">{"Пропустить"}</span>
        </Button>

        <Button
          size="lg"
          className="glow-primary-strong h-16 w-16 rounded-full bg-primary p-0"
          disabled={remainingLikes <= 0}
          onClick={() => handleAction("like")}
        >
          <Heart className="h-7 w-7 text-primary-foreground" fill="currentColor" />
          <span className="sr-only">{"Нравится"}</span>
        </Button>

        <Button
          variant="outline"
          size="lg"
          className="glass h-14 w-14 rounded-full border-0 p-0"
          disabled={remainingLikes <= 0}
          onClick={() => handleAction("super")}
        >
          <Star className="h-6 w-6 text-amber-400" fill="currentColor" />
          <span className="sr-only">{"Супер лайк"}</span>
        </Button>
      </div>
    </div>
  )
}
