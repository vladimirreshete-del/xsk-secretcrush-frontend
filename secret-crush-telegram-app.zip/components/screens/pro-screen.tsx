"use client"

import { ArrowLeft, Heart, Eye, Zap, Crown, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useAppStore } from "@/lib/store"

const FEATURES = [
  {
    icon: Heart,
    title: "Безлимитные лайки",
    description: "Лайкай сколько хочешь профилей каждый день",
  },
  {
    icon: Eye,
    title: "Узнай, кому ты нравишься",
    description: "Мгновенно увидь всех, у кого ты вызвал симпатию",
  },
  {
    icon: Zap,
    title: "Мгновенное открытие фото",
    description: "Больше не нужно ждать таймер обратного отсчёта",
  },
  {
    icon: Crown,
    title: "Приоритетная видимость",
    description: "Твой профиль будет показываться первым в ленте",
  },
]

export function ProScreen() {
  const setScreen = useAppStore((s) => s.setScreen)

  return (
    <div className="relative flex min-h-[100dvh] flex-col px-6 pb-8 pt-4">
      {/* Glow effects */}
      <div className="pointer-events-none absolute left-1/2 top-0 h-64 w-64 -translate-x-1/2 rounded-full bg-primary/15 blur-[100px]" />

      {/* Back */}
      <Button
        variant="ghost"
        size="sm"
        className="relative mb-4 w-fit gap-1.5 px-0 text-muted-foreground"
        onClick={() => setScreen("feed")}
      >
        <ArrowLeft className="h-4 w-4" />
        {"Назад"}
      </Button>

      {/* Header */}
      <div className="relative mb-8 text-center">
        <div className="glow-primary-strong mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/15">
          <Crown className="h-8 w-8 text-primary" />
        </div>
        <h1 className="text-2xl font-bold text-foreground">
          {"Раскрой тайну"}
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {"Получи максимум от SecretCrush"}
        </p>
      </div>

      {/* Features */}
      <div className="relative flex flex-1 flex-col gap-3">
        {FEATURES.map((feature) => (
          <div
            key={feature.title}
            className="glass flex items-start gap-3 rounded-xl p-4"
          >
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/15">
              <feature.icon className="h-5 w-5 text-primary" />
            </div>
            <div className="flex flex-col gap-0.5">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-foreground">
                  {feature.title}
                </span>
                <Check className="h-4 w-4 text-primary" />
              </div>
              <p className="text-xs leading-relaxed text-muted-foreground">
                {feature.description}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Price button */}
      <div className="relative mt-8">
        <Button
          size="lg"
          className="glow-primary-strong w-full rounded-full text-base font-bold"
        >
          {"399 \u20BD / месяц"}
        </Button>
        <p className="mt-2 text-center text-xs text-muted-foreground">
          {"Отмена в любое время. Автопродление."}
        </p>
      </div>
    </div>
  )
}
