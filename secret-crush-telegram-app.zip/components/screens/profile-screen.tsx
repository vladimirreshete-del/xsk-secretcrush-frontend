"use client"

import { useState, useRef } from "react"
import { Camera, X, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useAppStore } from "@/lib/store"

export function ProfileScreen() {
  const { profile, setProfile, setScreen } = useAppStore()
  const [name, setName] = useState(profile.name || "")
  const [age, setAge] = useState(profile.age?.toString() || "")
  const [bio, setBio] = useState(profile.bio || "")
  const [photos, setPhotos] = useState<string[]>(profile.photos || [])
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return
    Array.from(files).forEach((file) => {
      if (photos.length >= 3) return
      const reader = new FileReader()
      reader.onload = (ev) => {
        if (ev.target?.result) {
          setPhotos((prev) => [...prev.slice(0, 2), ev.target!.result as string])
        }
      }
      reader.readAsDataURL(file)
    })
  }

  const removePhoto = (index: number) => {
    setPhotos((prev) => prev.filter((_, i) => i !== index))
  }

  const isValid = name.trim() && age && parseInt(age) >= 18 && parseInt(age) <= 99

  const handleSave = () => {
    setProfile({
      name: name.trim(),
      age: parseInt(age),
      bio: bio.trim(),
      photos,
    })
    setScreen("feed")
  }

  return (
    <div className="relative flex min-h-[100dvh] flex-col px-6 pb-8 pt-12">
      <div className="pointer-events-none absolute left-0 top-20 h-48 w-48 rounded-full bg-primary/8 blur-[80px]" />

      <div className="relative mb-8">
        <div className="mb-1 flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/20">
            <User className="h-4 w-4 text-primary" />
          </div>
          <h1 className="text-xl font-bold text-foreground">{"Твой профиль"}</h1>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          {"Расскажи о себе"}
        </p>
      </div>

      <div className="relative flex flex-1 flex-col gap-5">
        {/* Photos */}
        <div className="flex flex-col gap-2">
          <Label className="text-sm font-medium text-foreground">
            {"Фото"} ({photos.length}/3)
          </Label>
          <div className="flex gap-3">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="glass relative flex h-24 w-24 items-center justify-center overflow-hidden rounded-xl"
              >
                {photos[i] ? (
                  <>
                    <img
                      src={photos[i]}
                      alt={`Фото ${i + 1}`}
                      className="h-full w-full object-cover"
                    />
                    <button
                      onClick={() => removePhoto(i)}
                      className="absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-full bg-background/80 text-foreground backdrop-blur-sm"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex h-full w-full flex-col items-center justify-center gap-1 text-muted-foreground transition-colors hover:text-primary"
                  >
                    <Camera className="h-5 w-5" />
                    <span className="text-[10px]">{"Добавить"}</span>
                  </button>
                )}
              </div>
            ))}
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={handlePhotoUpload}
          />
        </div>

        {/* Name */}
        <div className="flex flex-col gap-2">
          <Label className="text-sm font-medium text-foreground">
            {"Имя или псевдоним"}
          </Label>
          <Input
            placeholder="Как тебя называть?"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="rounded-xl border-border/50 bg-card/60 backdrop-blur-sm"
            maxLength={30}
          />
        </div>

        {/* Age */}
        <div className="flex flex-col gap-2">
          <Label className="text-sm font-medium text-foreground">{"Возраст"}</Label>
          <Input
            type="number"
            placeholder="Твой возраст"
            value={age}
            onChange={(e) => setAge(e.target.value)}
            className="rounded-xl border-border/50 bg-card/60 backdrop-blur-sm"
            min={18}
            max={99}
          />
        </div>

        {/* Bio */}
        <div className="flex flex-col gap-2">
          <Label className="text-sm font-medium text-foreground">
            {"О себе"} ({bio.length}/120)
          </Label>
          <Textarea
            placeholder="Пару слов о себе..."
            value={bio}
            onChange={(e) => setBio(e.target.value.slice(0, 120))}
            className="min-h-[80px] resize-none rounded-xl border-border/50 bg-card/60 backdrop-blur-sm"
            maxLength={120}
          />
        </div>
      </div>

      <Button
        size="lg"
        className="glow-primary mt-6 w-full rounded-full text-base font-semibold"
        disabled={!isValid}
        onClick={handleSave}
      >
        {"Сохранить и продолжить"}
      </Button>
    </div>
  )
}
