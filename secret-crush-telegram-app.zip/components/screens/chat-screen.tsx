"use client"

import { useState, useRef, useEffect } from "react"
import { ArrowLeft, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { CountdownTimer } from "@/components/countdown-timer"
import { useAppStore } from "@/lib/store"
import { MOCK_MATCHES, MOCK_MESSAGES } from "@/lib/mock-data"
import type { ChatMessage } from "@/lib/types"

interface ChatScreenProps {
  matchId: string
}

export function ChatScreen({ matchId }: ChatScreenProps) {
  const setScreen = useAppStore((s) => s.setScreen)
  const match = MOCK_MATCHES.find((m) => m.id === matchId)
  const [messages, setMessages] = useState<ChatMessage[]>(
    MOCK_MESSAGES[matchId] || []
  )
  const [input, setInput] = useState("")
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    })
  }, [messages])

  if (!match) {
    return (
      <div className="flex min-h-[60dvh] items-center justify-center">
        <p className="text-sm text-muted-foreground">{"Совпадение не найдено"}</p>
      </div>
    )
  }

  const handleSend = () => {
    if (!input.trim()) return
    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      senderId: "me",
      text: input.trim(),
      timestamp: new Date(),
    }
    setMessages((prev) => [...prev, newMsg])
    setInput("")
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <div className="flex h-[100dvh] flex-col bg-background">
      {/* Header */}
      <div className="glass-strong flex items-center gap-3 px-3 py-3">
        <Button
          variant="ghost"
          size="sm"
          className="h-8 w-8 p-0 text-foreground"
          onClick={() => setScreen("matches")}
        >
          <ArrowLeft className="h-5 w-5" />
          <span className="sr-only">{"Назад"}</span>
        </Button>
        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-primary/25 to-primary/5">
          <span className="text-sm font-bold text-primary">
            {match.user.name.charAt(0)}
          </span>
        </div>
        <div className="flex-1">
          <p className="text-sm font-semibold text-foreground">
            {match.user.name}
          </p>
        </div>
        <CountdownTimer targetDate={match.photosUnlockAt} />
      </div>

      {/* Countdown banner */}
      <div className="flex items-center justify-center bg-primary/8 px-4 py-2">
        <p className="text-xs text-primary">
          {"Фото откроются после окончания таймера"}
        </p>
      </div>

      {/* Messages */}
      <div
        ref={scrollRef}
        className="flex flex-1 flex-col gap-2 overflow-y-auto px-4 py-3"
      >
        {messages.length === 0 && (
          <div className="flex flex-1 items-center justify-center">
            <p className="text-sm text-muted-foreground">
              {"Начни разговор!"}
            </p>
          </div>
        )}
        {messages.map((msg) => {
          const isMe = msg.senderId === "me"
          return (
            <div
              key={msg.id}
              className={`flex ${isMe ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[75%] rounded-2xl px-3.5 py-2 ${
                  isMe
                    ? "glow-primary rounded-br-md bg-primary text-primary-foreground"
                    : "glass rounded-bl-md text-foreground"
                }`}
              >
                <p className="text-sm leading-relaxed">{msg.text}</p>
                <p
                  className={`mt-0.5 text-[10px] ${
                    isMe ? "text-primary-foreground/60" : "text-muted-foreground"
                  }`}
                >
                  {formatTime(msg.timestamp)}
                </p>
              </div>
            </div>
          )
        })}
      </div>

      {/* Input */}
      <div className="glass-strong px-3 py-2">
        <div className="flex items-center gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleSend()
            }}
            placeholder="Сообщение..."
            className="rounded-full border-border/50 bg-muted/50"
          />
          <Button
            size="sm"
            className="glow-primary h-9 w-9 shrink-0 rounded-full p-0"
            disabled={!input.trim()}
            onClick={handleSend}
          >
            <Send className="h-4 w-4" />
            <span className="sr-only">{"Отправить"}</span>
          </Button>
        </div>
      </div>
    </div>
  )
}
