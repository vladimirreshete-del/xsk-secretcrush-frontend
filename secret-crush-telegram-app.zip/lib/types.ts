export interface UserProfile {
  id: string
  name: string
  age: number
  bio: string
  photos: string[]
  city: string
  district: string
}

export interface Match {
  id: string
  user: UserProfile
  matchedAt: Date
  photosUnlockAt: Date
  lastMessage?: string
  unreadCount: number
}

export interface ChatMessage {
  id: string
  senderId: string
  text: string
  timestamp: Date
}

export interface LikeAction {
  type: "like" | "pass" | "super"
  targetUserId: string
}
