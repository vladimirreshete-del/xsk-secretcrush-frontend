"use client"

import { create } from "zustand"
import type { UserProfile } from "./types"

interface AppState {
  // Auth
  token: string | null
  setToken: (token: string | null) => void

  // Onboarding
  isOnboarded: boolean
  setOnboarded: (v: boolean) => void

  // Location
  city: string
  district: string
  setCity: (city: string) => void
  setDistrict: (district: string) => void

  // Profile
  profile: Partial<UserProfile>
  setProfile: (p: Partial<UserProfile>) => void

  // Feed
  dailyLikesUsed: number
  incrementLikes: () => void
  currentProfileIndex: number
  nextProfile: () => void

  // Current screen
  screen: string
  setScreen: (s: string) => void
}

export const useAppStore = create<AppState>((set) => ({
  token: null,
  setToken: (token) => set({ token }),

  isOnboarded: false,
  setOnboarded: (v) => set({ isOnboarded: v }),

  city: "",
  district: "",
  setCity: (city) => set({ city }),
  setDistrict: (district) => set({ district }),

  profile: {},
  setProfile: (p) => set((state) => ({ profile: { ...state.profile, ...p } })),

  dailyLikesUsed: 0,
  incrementLikes: () => set((state) => ({ dailyLikesUsed: state.dailyLikesUsed + 1 })),
  currentProfileIndex: 0,
  nextProfile: () => set((state) => ({ currentProfileIndex: state.currentProfileIndex + 1 })),

  screen: "onboarding",
  setScreen: (s) => set({ screen: s }),
}))
