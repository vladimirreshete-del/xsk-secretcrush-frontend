import type { UserProfile, Match, ChatMessage } from "./types"

export const CITIES = [
  "Москва",
  "Санкт-Петербург",
  "Новосибирск",
  "Екатеринбург",
  "Казань",
  "Нижний Новгород",
  "Челябинск",
  "Самара",
  "Омск",
  "Ростов-на-Дону",
]

export const DISTRICTS: Record<string, string[]> = {
  "Москва": ["Арбат", "Тверской", "Замоскворечье", "Хамовники", "Пресненский", "Басманный"],
  "Санкт-Петербург": ["Адмиралтейский", "Василеостровский", "Петроградский", "Центральный", "Московский"],
  "Новосибирск": ["Центральный", "Железнодорожный", "Заельцовский", "Калининский"],
  "Екатеринбург": ["Верх-Исетский", "Железнодорожный", "Кировский", "Ленинский"],
  "Казань": ["Авиастроительный", "Вахитовский", "Кировский", "Московский"],
  "Нижний Новгород": ["Автозаводский", "Канавинский", "Ленинский", "Московский"],
  "Челябинск": ["Калининский", "Курчатовский", "Ленинский", "Металлургический"],
  "Самара": ["Железнодорожный", "Кировский", "Ленинский", "Октябрьский"],
  "Омск": ["Центральный", "Кировский", "Ленинский", "Октябрьский"],
  "Ростов-на-Дону": ["Кировский", "Ленинский", "Октябрьский", "Первомайский"],
}

export const MOCK_PROFILES: UserProfile[] = [
  {
    id: "1",
    name: "Аня",
    age: 24,
    bio: "Люблю кофе и книги. Давай найдём уютное кафе вместе",
    photos: [],
    city: "Москва",
    district: "Арбат",
  },
  {
    id: "2",
    name: "Миша",
    age: 27,
    bio: "Фотограф, исследую городские пейзажи. Всегда с камерой",
    photos: [],
    city: "Москва",
    district: "Тверской",
  },
  {
    id: "3",
    name: "Катя",
    age: 22,
    bio: "Инструктор по йоге. Ищу того, с кем смотреть закаты",
    photos: [],
    city: "Москва",
    district: "Хамовники",
  },
  {
    id: "4",
    name: "Дмитрий",
    age: 29,
    bio: "Разработчик днём, диджей ночью. Музыка - мой язык",
    photos: [],
    city: "Москва",
    district: "Пресненский",
  },
  {
    id: "5",
    name: "Лена",
    age: 25,
    bio: "Любительница приключений. Пойдём в поход в выходные?",
    photos: [],
    city: "Москва",
    district: "Замоскворечье",
  },
]

const now = new Date()

export const MOCK_MATCHES: Match[] = [
  {
    id: "m1",
    user: MOCK_PROFILES[0],
    matchedAt: new Date(now.getTime() - 2 * 60 * 60 * 1000),
    photosUnlockAt: new Date(now.getTime() + 22 * 60 * 60 * 1000),
    lastMessage: "Привет! Рада совпадению",
    unreadCount: 1,
  },
  {
    id: "m2",
    user: MOCK_PROFILES[2],
    matchedAt: new Date(now.getTime() - 12 * 60 * 60 * 1000),
    photosUnlockAt: new Date(now.getTime() + 12 * 60 * 60 * 1000),
    lastMessage: "Ты занимаешься йогой?",
    unreadCount: 0,
  },
  {
    id: "m3",
    user: MOCK_PROFILES[4],
    matchedAt: new Date(now.getTime() - 20 * 60 * 60 * 1000),
    photosUnlockAt: new Date(now.getTime() + 4 * 60 * 60 * 1000),
    unreadCount: 3,
  },
]

export const MOCK_MESSAGES: Record<string, ChatMessage[]> = {
  m1: [
    { id: "msg1", senderId: "1", text: "Привет! Рада совпадению", timestamp: new Date(now.getTime() - 60 * 60 * 1000) },
    { id: "msg2", senderId: "me", text: "Привет! Как дела?", timestamp: new Date(now.getTime() - 55 * 60 * 1000) },
    { id: "msg3", senderId: "1", text: "Отлично! Только закончила книгу. А ты?", timestamp: new Date(now.getTime() - 50 * 60 * 1000) },
  ],
  m2: [
    { id: "msg4", senderId: "3", text: "Ты занимаешься йогой?", timestamp: new Date(now.getTime() - 6 * 60 * 60 * 1000) },
    { id: "msg5", senderId: "me", text: "Давно хочу попробовать!", timestamp: new Date(now.getTime() - 5 * 60 * 60 * 1000) },
  ],
  m3: [],
}

export const DAILY_LIKES_LIMIT = 10
